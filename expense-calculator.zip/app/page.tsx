"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Expense {
  category: string
  amount: number
}

interface CalculationResult {
  totalExpense: number
  remainingBalance: number
  warning: string
}

export default function ExpenseCalculator() {
  const [income, setIncome] = useState<number>(0)
  const [expenses, setExpenses] = useState<Expense[]>([{ category: "", amount: 0 }])
  const [result, setResult] = useState<CalculationResult | null>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const { toast } = useToast()

  const addExpense = () => {
    setExpenses([...expenses, { category: "", amount: 0 }])
  }

  const removeExpense = (index: number) => {
    if (expenses.length > 1) {
      setExpenses(expenses.filter((_, i) => i !== index))
    }
  }

  const updateExpense = (index: number, field: keyof Expense, value: string | number) => {
    const updatedExpenses = expenses.map((expense, i) => (i === index ? { ...expense, [field]: value } : expense))
    setExpenses(updatedExpenses)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (income <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid income amount",
        variant: "destructive",
      })
      return
    }

    const validExpenses = expenses.filter((exp) => exp.category.trim() && exp.amount > 0)
    if (validExpenses.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one valid expense",
        variant: "destructive",
      })
      return
    }

    setIsCalculating(true)
    toast({
      title: "Calculating expenses...",
      description: "Processing your financial data",
    })

    try {
      const response = await fetch("/api/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          income,
          expenses: validExpenses,
        }),
      })

      if (!response.ok) {
        throw new Error("Calculation failed")
      }

      const data = await response.json()
      setResult(data)

      toast({
        title: "Calculation Complete",
        description: "Your expense analysis is ready",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to calculate expenses. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsCalculating(false)
    }
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-2">Monthly Expense Calculator</h1>
          <p className="text-muted-foreground">Track your income and expenses to manage your budget effectively</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Financial Information</CardTitle>
            <CardDescription>Enter your monthly income and expenses below</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Income Input */}
              <div className="space-y-2">
                <Label htmlFor="income">Total Monthly Income *</Label>
                <Input
                  id="income"
                  type="number"
                  min="0"
                  step="0.01"
                  value={income || ""}
                  onChange={(e) => setIncome(Number.parseFloat(e.target.value) || 0)}
                  placeholder="Enter your monthly income"
                  required
                />
              </div>

              {/* Expenses Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Expenses</Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addExpense}
                    className="flex items-center gap-2 bg-transparent"
                  >
                    <Plus className="h-4 w-4" />
                    Add Expense
                  </Button>
                </div>

                <div className="space-y-3">
                  {expenses.map((expense, index) => (
                    <div key={index} className="flex gap-3 items-end">
                      <div className="flex-1">
                        <Label htmlFor={`category-${index}`}>Category</Label>
                        <Input
                          id={`category-${index}`}
                          type="text"
                          value={expense.category}
                          onChange={(e) => updateExpense(index, "category", e.target.value)}
                          placeholder="e.g., Rent, Food, Transportation"
                          required
                        />
                      </div>
                      <div className="flex-1">
                        <Label htmlFor={`amount-${index}`}>Amount</Label>
                        <Input
                          id={`amount-${index}`}
                          type="number"
                          min="0"
                          step="0.01"
                          value={expense.amount || ""}
                          onChange={(e) => updateExpense(index, "amount", Number.parseFloat(e.target.value) || 0)}
                          placeholder="0.00"
                          required
                        />
                      </div>
                      {expenses.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => removeExpense(index)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={isCalculating}>
                {isCalculating ? "Calculating..." : "Calculate"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Results Display */}
        {result && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Calculation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-lg">
                <div className="flex justify-between">
                  <span>Total Expenses:</span>
                  <span className="font-semibold">${result.totalExpense.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Remaining Balance:</span>
                  <span className={`font-semibold ${result.remainingBalance >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${result.remainingBalance.toFixed(2)}
                  </span>
                </div>
                {result.warning && (
                  <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
                    <p className="text-yellow-800 dark:text-yellow-200 font-medium">{result.warning}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
