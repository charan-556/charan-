import { type NextRequest, NextResponse } from "next/server"

interface Expense {
  category: string
  amount: number
}

interface RequestBody {
  income: number
  expenses: Expense[]
}

export async function POST(request: NextRequest) {
  try {
    const body: RequestBody = await request.json()
    const { income, expenses } = body

    // Validate input
    if (!income || income <= 0) {
      return NextResponse.json({ error: "Invalid income amount" }, { status: 400 })
    }

    if (!expenses || !Array.isArray(expenses) || expenses.length === 0) {
      return NextResponse.json({ error: "No expenses provided" }, { status: 400 })
    }

    // Calculate total expenses
    const totalExpense = expenses.reduce((sum, expense) => {
      return sum + (expense.amount || 0)
    }, 0)

    // Calculate remaining balance
    const remainingBalance = income - totalExpense

    // Generate warning message
    let warning = ""
    if (remainingBalance < 0) {
      warning = "⚠️ Warning: Your expenses exceed your income! Consider reducing expenses or increasing income."
    } else if (remainingBalance < income * 0.1) {
      warning = "💡 Tip: You have very little left after expenses. Consider building an emergency fund."
    } else if (remainingBalance > income * 0.5) {
      warning = "✅ Great job! You have a healthy amount left over. Consider investing or saving more."
    }

    return NextResponse.json({
      totalExpense,
      remainingBalance,
      warning,
    })
  } catch (error) {
    console.error("Calculation error:", error)
    return NextResponse.json({ error: "Failed to process calculation" }, { status: 500 })
  }
}
